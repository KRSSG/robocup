//
// C++ Implementation: framelimiter
//
// Description: This class can be used to limit the framerate of your game.
//
//
// Author: Stefan Zickler <szickler@cs.cmu.edu>, 2007
//
//
#include "framelimiter.h"

