//========================================================================
//  This software is free: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License Version 3,
//  as published by the Free Software Foundation.
//
//  This software is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  Version 3 in the file COPYING that came with this distribution.
//  If not, see <http://www.gnu.org/licenses/>.
//========================================================================
/*!
  \file    global_random.h
  \brief   C++ Interface: GlobalRandom
  \author  Stefan Zickler, (C) 2008
*/
//========================================================================

#include "random.h"
#ifndef GLOBAL_RANDOM_H_
#define GLOBAL_RANDOM_H_

/*!
  \class  GlobalRandom
  \brief  A singleton class to provide a single global instance of the Random class.
  \author Stefan Zickler, (C) 2008
*/
class GlobalRandom
  {
  public:
      static Random* getInstance();
  protected:
      GlobalRandom();
      GlobalRandom(const GlobalRandom&);
      GlobalRandom& operator= (const GlobalRandom&);
  private:
      static GlobalRandom* pinstance;
      Random * tool;
 };

#endif
